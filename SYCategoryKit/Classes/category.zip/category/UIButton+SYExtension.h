//
//  UIButton+SYExtension.h
//  SYCategoryKit
//
//  Created by Hyukooooh on 2022/3/22.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UIButton (SYExtension)
/// 增加点击区域
/// @param top 上
/// @param left 左
/// @param bottom 下
/// @param right 右
- (void)setExtraEdgeWithTop:(CGFloat)top left:(CGFloat)left bottom:(CGFloat)bottom right:(CGFloat)right;
@end

NS_ASSUME_NONNULL_END
