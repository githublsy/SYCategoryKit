//
//  UIButton+SYExtension.m
//  SYCategoryKit
//
//  Created by Hyukooooh on 2022/3/22.
//

#import "UIButton+SYExtension.h"
#import <objc/runtime.h>

static const char *UIButton_Extra_Top = "UIButton_Extra_Top";
static const char *UIButton_Extra_Left = "UIButton_Extra_Left";
static const char *UIButton_Extra_Bottom = "UIButton_Extra_Bottom";
static const char *UIButton_Extra_Right = "UIButton_Extra_Right";

@implementation UIButton (SYExtension)
- (void)setExtraEdgeWithTop:(CGFloat)top left:(CGFloat)left bottom:(CGFloat)bottom right:(CGFloat)right{
    objc_setAssociatedObject(self, &UIButton_Extra_Top, [NSNumber numberWithFloat:top], OBJC_ASSOCIATION_COPY_NONATOMIC);
    objc_setAssociatedObject(self, &UIButton_Extra_Left, [NSNumber numberWithFloat:left], OBJC_ASSOCIATION_COPY_NONATOMIC);
    objc_setAssociatedObject(self, &UIButton_Extra_Bottom, [NSNumber numberWithFloat:bottom], OBJC_ASSOCIATION_COPY_NONATOMIC);
    objc_setAssociatedObject(self, &UIButton_Extra_Right, [NSNumber numberWithFloat:right], OBJC_ASSOCIATION_COPY_NONATOMIC);
}

//新的点击区域
- (CGRect)extraedRect{
    NSNumber* topEdge = objc_getAssociatedObject(self, &UIButton_Extra_Top);
    NSNumber* rightEdge = objc_getAssociatedObject(self, &UIButton_Extra_Right);
    NSNumber* bottomEdge = objc_getAssociatedObject(self, &UIButton_Extra_Bottom);
    NSNumber* leftEdge = objc_getAssociatedObject(self, &UIButton_Extra_Left);
    if (topEdge && rightEdge && bottomEdge && leftEdge){
        return CGRectMake(self.bounds.origin.x - leftEdge.floatValue,
                          self.bounds.origin.y - topEdge.floatValue,
                          self.bounds.size.width + leftEdge.floatValue + rightEdge.floatValue,
                          self.bounds.size.height + topEdge.floatValue + bottomEdge.floatValue);
    }
    else{
        return self.bounds;
    }
}

- (UIView*)hitTest:(CGPoint) point withEvent:(UIEvent*) event{
    //获得了获得新范围的CGRect
    CGRect rect = [self extraedRect];
    if (CGRectEqualToRect(rect,self.bounds)){
        //如果新的点击范围与原始的一致，就调用super 看看点击范围是不是在父控件上
        return [super hitTest:point withEvent:event];
    }
    //如果触摸点为在新的点击范围内。响应者就为该view
    return CGRectContainsPoint(rect, point) ? self : nil;
}

@end
